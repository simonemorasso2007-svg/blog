<?php
include "db.php";
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$user_id = $_SESSION['user_id'];
$success = $_SESSION['success'] ?? '';
$error   = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);

$stmt_u = $conn->prepare("SELECT nome, cognome, email, created_at FROM users WHERE id = ?");
$stmt_u->bind_param("i", $user_id);
$stmt_u->execute();
$user_data = $stmt_u->get_result()->fetch_assoc();

$count_res = $conn->prepare("SELECT COUNT(*) as n, AVG(voto) as avg_voto FROM preferences WHERE user_id = ?");
$count_res->bind_param("i", $user_id);
$count_res->execute();
$stats = $count_res->get_result()->fetch_assoc();

include "header.php";
?>

<div class="container">
    <div class="profile-header">
        <div class="profile-avatar"><?= strtoupper(substr($_SESSION['username'], 0, 1)) ?></div>
        <div>
            <h2 style="font-family: var(--font-display); font-size: 2em; letter-spacing: 2px; text-transform: uppercase;">
                @<?= htmlspecialchars($_SESSION['username']) ?>
            </h2>
            <p style="color: var(--text-dim); font-size: 0.9em;">
                <?= htmlspecialchars($user_data['nome']) ?> <?= htmlspecialchars($user_data['cognome']) ?>
                &nbsp;·&nbsp;  <?= htmlspecialchars($user_data['email']) ?>
                &nbsp;·&nbsp;  Iscritto il <?= date('d M Y', strtotime($user_data['created_at'])) ?>
            </p>
            <div style="display: flex; gap: 20px; margin-top: 12px;">
                <div>
                    <span style="font-family: var(--font-display); font-size: 1.6em; color: var(--primary); letter-spacing: 1px;">
                        <?= $stats['n'] ?>
                    </span>
                    <span style="font-size: 0.82em; color: var(--text-dim); margin-left: 5px;">brani salvati</span>
                </div>
                <?php if ($stats['avg_voto']): ?>
                <div>
                    <span style="font-family: var(--font-display); font-size: 1.6em; color: var(--primary); letter-spacing: 1px;">
                        <?= number_format($stats['avg_voto'], 1) ?>
                    </span>
                    <span style="font-size: 0.82em; color: var(--text-dim); margin-left: 5px;">voto medio ⭐</span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="page-header" style="margin-bottom: 20px;">
        <h2 style="font-family: var(--font-display); font-size: 1.8em; letter-spacing: 2px; text-transform: uppercase; color: var(--text);">
            Aggiungi un <span style="color: var(--primary);">Brano</span>
        </h2>
        <p style="color: var(--text-dim); font-size: 0.9em; margin-top: 4px;">Condividilo con la community</p>
    </div>

    <?php if ($success): ?><div class="message success">✓ <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="message error">✕ <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <form action="save_music.php" method="POST" enctype="multipart/form-data">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0 16px;">
            <div>
                <label>Artista *</label>
                <input type="text" name="cantante" placeholder="es. Kendrick Lamar" required maxlength="100">
            </div>
            <div>
                <label>Titolo Canzone *</label>
                <input type="text" name="canzone" placeholder="es. Not Like Us" required maxlength="100">
            </div>
        </div>

        <label>Genere musicale</label>
        <input type="text" name="genere" placeholder="es. Hip-Hop, Pop, Rock..." maxlength="50">

        <label>La tua frase / barra preferita</label>
        <textarea name="commento" placeholder="Scrivi la strofa o la frase che ti ha colpito di più..." maxlength="255" style="height: 90px; resize: none;"></textarea>
        <div class="form-hint">Max 255 caratteri</div>

        <label>Immagine (copertina o foto)</label>
        <input type="file" name="foto" accept="image/*" style="padding: 10px; cursor: pointer;">
        <div class="form-hint">Formati accettati: JPG, PNG, WEBP</div>

        <label>Il tuo voto</label>
        <select name="voto" required>
            <option value="5">⭐⭐⭐⭐⭐ — Capolavoro</option>
            <option value="4">⭐⭐⭐⭐ — Molto bello</option>
            <option value="3">⭐⭐⭐ — Carino</option>
            <option value="2">⭐⭐ — Così così</option>
            <option value="1">⭐ — Non fa per me</option>
        </select>

        <button type="submit" style="margin-top: 16px;">🎵 Salva e Condividi</button>
    </form>
</div>

<div class="container">
    <div class="page-header" style="margin-bottom: 20px;">
        <h2 style="font-family: var(--font-display); font-size: 1.8em; letter-spacing: 2px; text-transform: uppercase; color: var(--text);">
            I tuoi <span style="color: var(--primary);">Preferiti</span>
        </h2>
    </div>

    <?php
    $stmt = $conn->prepare("SELECT * FROM preferences WHERE user_id = ? ORDER BY id DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0):
        while ($row = $result->fetch_assoc()):
    ?>
    <div class="music-item">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px;">
            <div style="flex: 1;">
                <h3><?= htmlspecialchars($row['cantante']) ?> — <?= htmlspecialchars($row['canzone']) ?></h3>
                <?php if ($row['genere']): ?>
                    <span class="badge badge-genre" style="margin-top: 6px; display: inline-block;">
                        <?= htmlspecialchars($row['genere']) ?>
                    </span>
                <?php endif; ?>
            </div>
            <a href="delete_music.php?id=<?= $row['id'] ?>"
               onclick="return confirm('Vuoi eliminare questo brano? Verrà rimosso anche dalla community.')"
               class="delete-link">🗑 Elimina</a>
        </div>

        <?php if ($row['immagine']): ?>
            <img src="uploads/<?= $row['immagine'] ?>" class="music-item-img" alt="<?= htmlspecialchars($row['cantante']) ?>">
        <?php endif; ?>

        <?php if ($row['commento']): ?>
            <p style="margin-top: 10px; font-style: italic; border-left: 2px solid var(--primary); padding-left: 12px; color: var(--text-dim);">
                "<?= nl2br(htmlspecialchars($row['commento'])) ?>"
            </p>
        <?php endif; ?>

        <p style="margin-top: 10px;" class="stars"><?= str_repeat('⭐', $row['voto']) ?></p>
    </div>
    <?php endwhile;
    else: ?>
        <div style="text-align: center; padding: 40px 0; color: var(--text-dim);">
            <div style="font-size: 3em; margin-bottom: 16px;">🎵</div>
            <p>Non hai ancora salvato nessun brano.</p>
            <p style="font-size: 0.9em; margin-top: 8px; color: var(--text-muted);">Usa il form qui sopra per aggiungere il primo!</p>
        </div>
    <?php endif; ?>
</div>

<?php include "footer.php"; ?>
