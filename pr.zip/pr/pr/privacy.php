<?php include "db.php"; include "header.php"; ?>

<div style="max-width: 760px; margin: 0 auto;">

    <div class="page-header">
        <h2>Privacy <span style="color: var(--primary);">&amp; Cookie</span> Policy</h2>
        <p style="color: var(--text-dim);">Aggiornato il 29° Marzo 2026 — In conformità al Regolamento UE 2016/679 (GDPR)</p>
    </div>

    <div class="container" style="margin-bottom: 16px;">
        <p style="color: var(--text-dim); line-height: 1.8;">
            La presente Privacy Policy descrive come <strong style="color: var(--text);">Beltify</strong> raccoglie, utilizza e protegge
            le informazioni personali degli utenti che visitano e utilizzano i servizi della piattaforma
            accessibile all'indirizzo <span style="color: var(--primary);">beltify.it</span>.
            Ti invitiamo a leggere attentamente questo documento prima di utilizzare il sito.
        </p>
    </div>

    <div class="info-section">
        <h3>1. Titolare del Trattamento</h3>
        <p>
            Il Titolare del Trattamento dei dati personali è <strong>Beltify</strong>, con sede in Genova (GE), Italia.
            Per qualsiasi richiesta relativa alla privacy puoi scrivere a:
            <a href="mailto:privacy@beltify.it" style="color: var(--primary);">privacy@beltify.it</a>
        </p>
    </div>

    <div class="info-section">
        <h3>2. Dati Personali Raccolti</h3>
        <p>Raccogliamo i seguenti dati esclusivamente quando li fornisci volontariamente:</p>
        <ul style="margin-top: 12px; padding-left: 20px; color: var(--text-dim); line-height: 2;">
            <li><strong style="color: var(--text);">Dati di registrazione:</strong> nome, cognome, username, indirizzo email e password (archiviata in forma cifrata con bcrypt).</li>
            <li><strong style="color: var(--text);">Contenuti generati:</strong> brani salvati, recensioni, commenti e immagini caricate dall'utente.</li>
            <li><strong style="color: var(--text);">Dati di sessione:</strong> identificatore di sessione temporaneo necessario per il login.</li>
        </ul>
        <p style="margin-top: 12px;">Non raccogliamo dati di navigazione, indirizzi IP per scopi di profilazione, né utilizziamo tracker pubblicitari di terze parti.</p>
    </div>

    <div class="info-section">
        <h3>3. Finalità e Base Giuridica del Trattamento</h3>
        <p>I dati vengono trattati per le seguenti finalità:</p>
        <ul style="margin-top: 12px; padding-left: 20px; color: var(--text-dim); line-height: 2;">
            <li><strong style="color: var(--text);">Erogazione del servizio</strong> — gestione account, pubblicazione contenuti, commenti e like. Base giuridica: esecuzione di un contratto (Art. 6.1.b GDPR).</li>
            <li><strong style="color: var(--text);">Sicurezza della piattaforma</strong> — prevenzione di accessi non autorizzati e abusi. Base giuridica: legittimo interesse (Art. 6.1.f GDPR).</li>
            <li><strong style="color: var(--text);">Adempimento obblighi legali</strong> — ove richiesto dalla legge italiana o europea. Base giuridica: obbligo legale (Art. 6.1.c GDPR).</li>
        </ul>
    </div>

    <div class="info-section" id="cookie">
        <h3>4. Cookie Policy</h3>
        <p>Utilizziamo esclusivamente <strong style="color: var(--text);">cookie tecnici strettamente necessari</strong>, senza i quali alcune funzionalità del sito non sarebbero disponibili:</p>
        <div style="margin-top: 14px; background: var(--bg); padding: 16px; border-radius: 8px;">
            <table style="width: 100%; font-size: 0.88em; color: var(--text-dim); border-collapse: collapse;">
                <thead>
                    <tr style="color: var(--text); border-bottom: 1px solid var(--border);">
                        <th style="padding: 8px 10px; text-align: left;">Nome</th>
                        <th style="padding: 8px 10px; text-align: left;">Tipo</th>
                        <th style="padding: 8px 10px; text-align: left;">Scopo</th>
                        <th style="padding: 8px 10px; text-align: left;">Durata</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid var(--border);">
                        <td style="padding: 8px 10px;">PHPSESSID</td>
                        <td style="padding: 8px 10px;">Tecnico</td>
                        <td style="padding: 8px 10px;">Gestione sessione di login</td>
                        <td style="padding: 8px 10px;">Sessione</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 10px;">beltify_cookie_consent</td>
                        <td style="padding: 8px 10px;">Tecnico</td>
                        <td style="padding: 8px 10px;">Salva la preferenza sul banner cookie</td>
                        <td style="padding: 8px 10px;">Persistente (localStorage)</td>
                    </tr>
                </tbody>
            </table>
        </div>
        </div>

    <div class="info-section">
        <h3>5. Condivisione dei Dati con Terze Parti</h3>
        <p>
            Beltify <strong style="color: var(--text);">non vende, non affitta e non cede</strong> i tuoi dati personali a terze parti per scopi commerciali o pubblicitari.
           
        </p>
    </div>

    <div class="info-section">
        <h3>6. Contenuti Pubblicati dagli Utenti</h3>
        <p>
            Pubblicando contenuti su Beltify (recensioni, commenti, immagini), l'utente dichiara di possederne i diritti
            o di avere le autorizzazioni necessarie per la pubblicazione.
            Beltify si riserva il diritto di rimuovere, senza preavviso, contenuti che violino la legge, i diritti di terzi
            o le regole della community.
        </p>
    </div>

    <div class="info-section">
        <h3>7. Sicurezza dei Dati</h3>
        <p>
            Adottiamo misure tecniche e organizzative adeguate per proteggere i tuoi dati da accessi non autorizzati,
            perdita o alterazione. Le password sono archiviate esclusivamente in forma cifrata con l'algoritmo bcrypt.
            Le sessioni vengono rigenerati ad ogni login per prevenire session fixation attacks.
            Nonostante queste misure, nessun sistema è completamente immune da rischi.
        </p>
    </div>

    <div class="info-section" id="termini">
        <h3>8. I Tuoi Diritti (GDPR)</h3>
        <p>In qualità di interessato, hai il diritto di:</p>
        <ul style="margin-top: 12px; padding-left: 20px; color: var(--text-dim); line-height: 2;">
            <li><strong style="color: var(--text);">Accesso</strong> — ricevere copia dei tuoi dati personali trattati.</li>
            <li><strong style="color: var(--text);">Rettifica</strong> — correggere dati inesatti o incompleti.</li>
            <li><strong style="color: var(--text);">Cancellazione</strong> — richiedere la rimozione di tutti i tuoi dati ("diritto all'oblio").</li>
            <li><strong style="color: var(--text);">Portabilità</strong> — ricevere i tuoi dati in formato strutturato e leggibile.</li>
            <li><strong style="color: var(--text);">Opposizione</strong> — opporti al trattamento basato su legittimo interesse.</li>
            <li><strong style="color: var(--text);">Limitazione</strong> — richiedere la sospensione temporanea del trattamento.</li>
        </ul>
        <p style="margin-top: 12px;">
            Per esercitare i tuoi diritti scrivi a <a href="mailto:privacy@beltify.it" style="color: var(--primary);">privacy@beltify.it</a>.
            Hai inoltre il diritto di presentare reclamo al Garante per la Protezione dei Dati Personali
            (<a href="https://www.garanteprivacy.it" target="_blank" rel="noopener" style="color: var(--primary);">www.garanteprivacy.it</a>).
        </p>
    </div>

    <div class="info-section">
        <h3>9. Termini di Servizio</h3>
        <p>Utilizzando Beltify accetti i seguenti termini:</p>
        <ul style="margin-top: 12px; padding-left: 20px; color: var(--text-dim); line-height: 2;">
            <li>È vietata la pubblicazione di contenuti offensivi, discriminatori, illegali o che violino i diritti altrui.</li>
            <li>Ogni account è personale e non cedibile. È vietato creare account falsi o impersonare altri utenti.</li>
            <li>Beltify si riserva il diritto di sospendere o eliminare account che violino questi termini.</li>
            <li>Il servizio è fornito "così com'è" e potrebbe essere soggetto a interruzioni per manutenzione.</li>
            <li>La legge applicabile è quella italiana. Foro competente: Genova (GE).</li>
        </ul>
    </div>

    

    <div style="margin-top: 30px; padding: 18px 20px; background: var(--bg); border-radius: var(--radius); font-size: 0.88em; color: var(--text-muted); border: 1px solid var(--border);">
         <strong>Ultimo aggiornamento:</strong> 29° Marzo 2026 | 
        Versione 2.0 |
        Le modifiche significative saranno comunicate agli utenti registrati via email.
    </div>

</div>

<?php include "footer.php"; ?>
