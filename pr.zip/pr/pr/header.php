<?php $current_page = basename($_SERVER['PHP_SELF']); ?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beltify - Community Musicale</title>
    <meta name="description" content="Beltify è la community musicale italiana. Condividi i tuoi brani preferiti, scopri nuovi artisti e connettiti con altri appassionati di musica.">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="cookie-overlay" class="cookie-overlay">
        <div class="cookie-modal">
            <div class="cookie-modal-icon"></div>
            <h2 class="cookie-modal-title">Prima di entrare</h2>
            <p class="cookie-modal-text">
                Beltify utilizza <strong>cookie tecnici</strong> strettamente necessari per gestire la tua sessione di accesso.
                Senza di essi il sito non può funzionare correttamente.
            </p>
            <p class="cookie-modal-text" style="margin-top:10px;">
                Nessun cookie pubblicitario, nessun tracciamento di terze parti.
                Leggi la nostra <a href="Privacy-policy.pdf" target="_blank" class="cookie-link">Privacy &amp; Cookie Policy</a> per saperne di più.
            </p>
            <div class="cookie-modal-actions">
                <button id="accept-cookies" class="cookie-btn-accept">✓ Accetta e continua</button>
                <button id="reject-cookies" class="cookie-btn-reject">Rifiuta</button>
            </div>
            <p class="cookie-modal-note">
                Rifiutando, le funzionalità di login e salvataggio non saranno disponibili.
            </p>
        </div>
    </div>

    <header class="header">
        <a class="logo" href="index.php">
            <img src="icons8-rap-48.png" alt="Beltify Logo">
            <h1>Beltify</h1>
        </a>

        <nav class="navbar">
            <div class="nav-links">
                <a href="index.php" <?php if($current_page=='index.php') echo 'class="active"'; ?>>Home</a>
                <a href="articoli_list.php" <?php if($current_page=='articoli_list.php') echo 'class="active"'; ?>>Recensioni</a>
                <a href="chi-siamo.php" <?php if($current_page=='chi-siamo.php') echo 'class="active"'; ?>>Chi Siamo</a>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <a href="admin_dashboard.php" class="admin-link <?php if($current_page=='admin_dashboard.php') echo 'active'; ?>">⚙ Admin</a>
                <?php endif; ?>
            </div>

            <form action="search_users.php" method="GET" class="search-form">
                <input type="text" name="q" placeholder=" Cerca profili..." required>
            </form>

            <div class="nav-auth">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <span class="nav-greeting">Ciao, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
                    <a href="home.php" class="nav-profile-btn <?php if($current_page=='home.php') echo 'active'; ?>">
                        <span class="nav-avatar"><?php echo strtoupper(substr($_SESSION['username'],0,1)); ?></span>
                        Profilo
                    </a>
                    <a href="logout.php" class="btn-accedi">Esci</a>
                <?php else: ?>
                    <a href="login.php" class="btn-accedi <?php if($current_page=='login.php') echo 'active'; ?>">Accedi</a>
                    <a href="register.php" class="btn-registrati <?php if($current_page=='register.php') echo 'active'; ?>">Registrati</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <script>
        (function() {
            var overlay = document.getElementById("cookie-overlay");
            var consent = localStorage.getItem("beltify_cookie_consent");
            if (!consent) {
                overlay.style.display = "flex";
                document.body.style.overflow = "hidden";
            }
            document.getElementById("accept-cookies").addEventListener("click", function() {
                localStorage.setItem("beltify_cookie_consent", "accepted");
                overlay.style.display = "none";
                document.body.style.overflow = "";
            });
            document.getElementById("reject-cookies").addEventListener("click", function() {
                localStorage.setItem("beltify_cookie_consent", "rejected");
                overlay.style.display = "none";
                document.body.style.overflow = "";
            });
        })();
    </script>

    <main class="main">