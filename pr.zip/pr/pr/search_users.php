<?php
include "db.php";
include "header.php";

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
?>

<div class="page-header">
    <h2>Cerca <span style="color: var(--primary);">Profili</span></h2>
    <?php if ($search): ?>
        <p style="color: var(--text-dim);">Risultati per: "<?= htmlspecialchars($search) ?>"</p>
    <?php else: ?>
        <p style="color: var(--text-dim);">Inserisci un nome o username nella barra di ricerca in alto.</p>
    <?php endif; ?>
</div>

<div style="max-width: 600px;">
    <?php
    if ($search !== '') {
        $stmt = $conn->prepare("
            SELECT u.username, u.nome, u.cognome, u.created_at,
                   (SELECT COUNT(*) FROM preferences WHERE user_id = u.id) as brani
            FROM users u
            WHERE u.username LIKE ? OR u.nome LIKE ? OR u.cognome LIKE ?
            ORDER BY u.username
            LIMIT 30
        ");
        $like = "%$search%";
        $stmt->bind_param("sss", $like, $like, $like);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0):
            while ($user = $result->fetch_assoc()): ?>
            <div class="user-card">
                <div class="user-avatar-sm"><?= strtoupper(substr($user['username'], 0, 1)) ?></div>
                <div style="flex: 1;">
                    <div style="font-weight: 700;">@<?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.88em; color: var(--text-dim); margin-top: 2px;">
                        <?= htmlspecialchars($user['nome']) ?> <?= htmlspecialchars($user['cognome']) ?>
                        &nbsp;·&nbsp; <?= $user['brani'] ?> brani salvati
                    </div>
                </div>
                <div style="font-size: 0.8em; color: var(--text-muted);">
                    Dal <?= date('M Y', strtotime($user['created_at'])) ?>
                </div>
            </div>
            <?php endwhile;
        else: ?>
            <div style="text-align: center; padding: 50px 0; color: var(--text-dim);">
                <div style="font-size: 3em; margin-bottom: 16px;"></div>
                <p>Nessun utente trovato per "<?= htmlspecialchars($search) ?>".</p>
                <p style="font-size: 0.9em; color: var(--text-muted); margin-top: 8px;">Prova con un username diverso.</p>
            </div>
        <?php endif;
    } else { ?>
        <div style="text-align: center; padding: 50px 0; color: var(--text-dim);">
            <div style="font-size: 3em; margin-bottom: 16px;"></div>
            <p>Cerca un utente della community di Beltify.</p>
        </div>
    <?php } ?>
</div>

<?php include "footer.php"; ?>
