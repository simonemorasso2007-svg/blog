<?php
include "db.php";
$error = '';
$success = '';

if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit;
}

if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $email    = trim(strtolower($_POST['email']));
    $password = $_POST['password'];
    $nome     = trim($_POST['nome']);
    $cognome  = trim($_POST['cognome']);

    $blacklist = ['administrator', 'staff', 'beltify', 'moderatore', 'admin', 'support'];

    if (in_array(strtolower($username), $blacklist)) {
        $error = "Questo username è riservato.";
    } elseif (!preg_match('/^[a-zA-Z0-9_\.]{3,50}$/', $username)) {
        $error = "Username non valido: usa solo lettere, numeri, _ o . (min 3 caratteri).";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Indirizzo email non valido.";
    } elseif ($password !== $_POST['confirm_password']) {
        $error = "Le password non coincidono.";
    } elseif (strlen($password) < 8) {
        $error = "La password deve essere di almeno 8 caratteri.";
    } else {
        $hashed_pw = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, nome, cognome, role) VALUES (?, ?, ?, ?, ?, 'user')");
        $stmt->bind_param("sssss", $username, $email, $hashed_pw, $nome, $cognome);

        if ($stmt->execute()) {
            $success = "Registrazione completata! Verrai reindirizzato al login...";
            header("refresh:2;url=login.php");
        } else {
            $error = "Username o Email già in uso.";
        }
    }
}

include "header.php";
?>

<div class="container small" style="max-width: 480px;">
    <div style="text-align: center; margin-bottom: 28px;">
        <div style="font-size: 2.5em; margin-bottom: 10px;"></div>
        <h2 style="font-family: var(--font-display); font-size: 2em; letter-spacing: 3px; text-transform: uppercase;">Crea Account</h2>
        <p style="color: var(--text-dim); font-size: 0.92em; margin-top: 6px;">Unisciti alla community di Beltify</p>
    </div>

    <?php if ($error): ?>
        <div class="message error"> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="message success"> <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0 12px;">
            <div>
                <label>Nome *</label>
                <input type="text" name="nome" placeholder="Mario" required maxlength="50">
            </div>
            <div>
                <label>Cognome *</label>
                <input type="text" name="cognome" placeholder="Rossi" required maxlength="50">
            </div>
        </div>

        <label>Username *</label>
        <input type="text" name="username" placeholder="mario_rossi" required maxlength="50" autocomplete="username">
        <div class="form-hint">Solo lettere, numeri, _ e . — min 3 caratteri</div>

        <label>Email *</label>
        <input type="email" name="email" placeholder="mario@email.com" required maxlength="100" autocomplete="email">

        <label>Password *</label>
        <input type="password" name="password" placeholder="Min. 8 caratteri" required autocomplete="new-password">
        <div class="form-hint">Almeno 8 caratteri</div>

        <label>Conferma Password *</label>
        <input type="password" name="confirm_password" placeholder="Ripeti la password" required autocomplete="new-password">

       

        <button type="submit" name="register">Crea Account Gratis</button>
    </form>

    <div style="text-align: center; margin-top: 20px; color: var(--text-dim); font-size: 0.9em;">
        Hai già un account?
        <a href="login.php" style="color: var(--primary); font-weight: 600;">Accedi →</a>
    </div>
</div>

<?php include "footer.php"; ?>
