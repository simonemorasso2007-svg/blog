<?php
include "db.php";
include "header.php";

$genere_filter = isset($_GET['genere']) ? trim($_GET['genere']) : '';

$generi_res = $conn->query("SELECT DISTINCT genere FROM preferences WHERE genere IS NOT NULL AND genere != '' ORDER BY genere");
?>

<div class="page-header">
    <h2>Recensioni <span>Community</span></h2>
    <p>Scopri cosa ascoltano gli altri utenti — lasciati ispirare </p>
</div>

<?php if ($generi_res && $generi_res->num_rows > 0): ?>
<div style="margin-bottom: 28px; display: flex; flex-wrap: wrap; gap: 8px; align-items: center;">
    <span style="color: var(--text-dim); font-size: 0.88em; margin-right: 4px;">Filtra:</span>
    <a href="articoli_list.php" class="badge badge-genre" style="text-decoration:none; <?= $genere_filter === '' ? 'background: var(--primary); color: white;' : '' ?>">Tutti</a>
    <?php while ($g = $generi_res->fetch_assoc()): ?>
        <a href="articoli_list.php?genere=<?= urlencode($g['genere']) ?>" class="badge badge-genre" 
           style="text-decoration:none; <?= $genere_filter === $g['genere'] ? 'background: var(--primary); color: white;' : '' ?>">
            <?= htmlspecialchars($g['genere']) ?>
        </a>
    <?php endwhile; ?>
</div>
<?php endif; ?>

<div class="articles-grid">
<?php
if ($genere_filter !== '') {
    $stmt = $conn->prepare("
        SELECT a.*, p.genere 
        FROM articoli a 
        LEFT JOIN preferences p ON a.titolo = CONCAT(p.cantante, ' - ', p.canzone)
        WHERE p.genere = ?
        ORDER BY a.data_creazione DESC
    ");
    $stmt->bind_param("s", $genere_filter);
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    $res = $conn->query("SELECT * FROM articoli ORDER BY data_creazione DESC");
}

if ($res->num_rows > 0):
    while ($art = $res->fetch_assoc()): ?>
    <div class="music-card">
        <?php if ($art['immagine']): ?>
            <div class="card-img-wrapper">
                <img src="uploads/<?= $art['immagine'] ?>" class="card-img" alt="<?= htmlspecialchars($art['titolo']) ?>">
            </div>
        <?php else: ?>
            <div class="img-placeholder"></div>
        <?php endif; ?>

        <div class="card-content">
            <h3><?= htmlspecialchars($art['titolo']) ?></h3>
            <p><?= nl2br(htmlspecialchars(mb_substr($art['descrizione'], 0, 100))) ?>...</p>
            <div style="font-size:0.8em; color: var(--text-muted); margin-top: 8px;">
                <?= date('d M Y', strtotime($art['data_creazione'])) ?>
            </div>
            <div class="card-footer">
                <a href="articolo.php?id=<?= $art['id'] ?>" class="btn-more">Scopri →</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="like.php?id=<?= $art['id'] ?>" class="like-badge"> <?= $art['likes'] ?></a>
                <?php else: ?>
                    <span class="like-badge"> <?= $art['likes'] ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endwhile;
else: ?>
    <p style="text-align: center; width: 100%; color: var(--text-dim); padding: 40px 0;">
        Nessuna recensione trovata<?= $genere_filter ? ' per questo genere' : '' ?>. 
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="home.php" style="color: var(--primary);">Sii il primo!</a>
        <?php endif; ?>
    </p>
<?php endif; ?>
</div>

<?php include "footer.php"; ?>
