<?php
include "db.php";

if (isset($_SESSION['user_id']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $commento = trim(strip_tags($_POST['commento'])); 
    $art_id = (int)$_POST['articolo_id'];
    if (mb_strlen($commento) > 50) {
        $commento = mb_substr($commento, 0, 50);
    }

    if (!empty($commento) && $art_id > 0) {
        $stmt = $conn->prepare("INSERT INTO commenti (commento, user_id, articolo_id) VALUES (?, ?, ?)");
        $stmt->bind_param("sii", $commento, $_SESSION['user_id'], $art_id);
        $stmt->execute();
    }
    header("Location: articolo.php?id=" . $art_id); 
    exit;
} else {
    header("Location: index.php");
    exit;
}