SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS commenti;
DROP TABLE IF EXISTS preferences;
DROP TABLE IF EXISTS articoli;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    nome VARCHAR(50) NOT NULL,
    cognome VARCHAR(50) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE articoli (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titolo VARCHAR(255) NOT NULL,
    descrizione TEXT NOT NULL,
    immagine VARCHAR(255) DEFAULT NULL,
    data_creazione DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE preferences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    cantante VARCHAR(100) NOT NULL,
    canzone VARCHAR(100) NOT NULL,
    genere VARCHAR(50),
    commento TEXT,
    voto INT NOT NULL,
    immagine VARCHAR(255) DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE commenti (
    id INT AUTO_INCREMENT PRIMARY KEY,
    commento TEXT NOT NULL,
    user_id INT NOT NULL,
    articolo_id INT NOT NULL,
    data_creazione DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (articolo_id) REFERENCES articoli(id) ON DELETE CASCADE
);
ALTER TABLE articoli ADD COLUMN likes INT DEFAULT 0;

CREATE TABLE articolo_likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,   
    articolo_id INT NOT NULL,
    UNIQUE KEY (user_id, articolo_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (articolo_id) REFERENCES articoli(id) ON DELETE CASCADE
);
ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user';

ALTER TABLE commenti DROP FOREIGN KEY commenti_ibfk_2;
ALTER TABLE commenti ADD CONSTRAINT commenti_ibfk_2 
FOREIGN KEY (articolo_id) REFERENCES articoli(id) ON DELETE CASCADE;