<?php
include "db.php";
$error = '';

if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit;
}

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $username;
            $_SESSION['role']     = $user['role'];
            header("Location: home.php");
            exit;
        } else {
            $error = "Username o password non corretti.";
        }
    } else {
        $error = "Username o password non corretti.";
    }
}

include "header.php";
?>

<div class="container small">
    <div style="text-align: center; margin-bottom: 28px;">
        <div style="font-size: 2.5em; margin-bottom: 10px;"></div>
        <h2 style="font-family: var(--font-display); font-size: 2em; letter-spacing: 3px; text-transform: uppercase;">Bentornato</h2>
        <p style="color: var(--text-dim); font-size: 0.92em; margin-top: 6px;">Accedi al tuo account Beltify</p>
    </div>

    <?php if ($error): ?>
        <div class="message error">✕ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" placeholder="Il tuo username" required autocomplete="username">

        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••" required autocomplete="current-password">

        <button type="submit" name="login" style="margin-top: 16px;">Accedi</button>
    </form>

    <div style="text-align: center; margin-top: 20px; color: var(--text-dim); font-size: 0.9em;">
        Non hai un account?
        <a href="register.php" style="color: var(--primary); font-weight: 600;">Registrati gratis →</a>
    </div>
</div>

<?php include "footer.php"; ?>
