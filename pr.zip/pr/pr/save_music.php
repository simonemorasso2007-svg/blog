<?php
include "db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $cantante = mb_substr(trim($_POST['cantante']), 0, 100);
    $canzone  = mb_substr(trim($_POST['canzone']), 0, 100);
    $genere   = mb_substr(trim($_POST['genere']), 0, 50);
    $commento = mb_substr(trim($_POST['commento']), 0, 255);
    $voto     = max(1, min(5, (int)$_POST['voto']));

    $user_id  = $_SESSION['user_id'];
    $username = $_SESSION['username'];
    $nome_file = null;

    if (!is_dir('uploads')) { mkdir('uploads', 0777, true); }

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        $file_type = mime_content_type($_FILES['foto']['tmp_name']);

        if (in_array($file_type, $allowed_types) && $_FILES['foto']['size'] <= 5 * 1024 * 1024) {
            $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
            $nome_file = time() . "_" . bin2hex(random_bytes(6)) . "." . strtolower($ext);
            move_uploaded_file($_FILES['foto']['tmp_name'], "uploads/" . $nome_file);
        } else {
            $_SESSION['error'] = "Immagine non valida (max 5MB, formati: JPG, PNG, WEBP, GIF).";
            header("Location: home.php");
            exit;
        }
    }

    if (!empty($cantante) && !empty($canzone)) {
        $check = $conn->prepare("SELECT id FROM preferences WHERE user_id = ? AND cantante = ? AND canzone = ?");
        $check->bind_param("iss", $user_id, $cantante, $canzone);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $_SESSION['error'] = "Hai già salvato questo brano!";
            header("Location: home.php");
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO preferences (user_id, cantante, canzone, genere, commento, voto, immagine) VALUES (?, ?, ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("issssis", $user_id, $cantante, $canzone, $genere, $commento, $voto, $nome_file);
            if ($stmt->execute()) {
                $titolo_art = $cantante . " - " . $canzone;
                $desc_art = "Postato da @$username\n\n" . ($commento ?: 'Nessuna nota aggiunta.');

                $stmt_art = $conn->prepare("INSERT INTO articoli (titolo, descrizione, immagine) VALUES (?, ?, ?)");
                if ($stmt_art) {
                    $stmt_art->bind_param("sss", $titolo_art, $desc_art, $nome_file);
                    $stmt_art->execute();
                }
                $_SESSION['success'] = "Brano salvato e condiviso con la community! 🎵";
            } else {
                $_SESSION['error'] = "Errore nel salvataggio. Riprova.";
            }
        }
    } else {
        $_SESSION['error'] = "Artista e Titolo sono obbligatori.";
    }
}

header("Location: home.php");
exit;
