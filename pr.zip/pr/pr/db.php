<?php
session_start();
$conn = new mysqli("localhost", "root", "", "musicblog");
if ($conn->connect_error) {
    die("Errore connessione Database");
}
?>