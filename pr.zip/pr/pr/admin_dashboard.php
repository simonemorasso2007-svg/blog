<?php
include "db.php";
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
include "header.php";

$tot_users    = $conn->query("SELECT COUNT(*) as n FROM users")->fetch_assoc()['n'];
$tot_articles = $conn->query("SELECT COUNT(*) as n FROM articoli")->fetch_assoc()['n'];
$tot_comments = $conn->query("SELECT COUNT(*) as n FROM commenti")->fetch_assoc()['n'];
$tot_likes    = $conn->query("SELECT COALESCE(SUM(likes),0) as n FROM articoli")->fetch_assoc()['n'];
?>

<div class="page-header">
    <h2>Pannello <span style="color: var(--primary);">Admin</span></h2>
    <p style="color: var(--text-dim);">Benvenuto, @<?= htmlspecialchars($_SESSION['username']) ?> — Gestisci tutti i contenuti del sito.</p>
</div>

<div class="stats-bar" style="margin-bottom: 25px;">
    <div class="stat-item">
        <div class="stat-number"><?= $tot_users ?></div>
        <div class="stat-label">Utenti</div>
    </div>
    <div class="stat-item">
        <div class="stat-number"><?= $tot_articles ?></div>
        <div class="stat-label">Articoli</div>
    </div>
    <div class="stat-item">
        <div class="stat-number"><?= $tot_comments ?></div>
        <div class="stat-label">Commenti</div>
    </div>
    <div class="stat-item">
        <div class="stat-number"><?= $tot_likes ?></div>
        <div class="stat-label">Like totali</div>
    </div>
</div>

<div class="container">
    <h3 style="font-family: var(--font-display); font-size: 1.5em; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 20px;">
        Gestione <span style="color: var(--primary);">Articoli</span>
    </h3>

    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Titolo</th>
                <th>Likes</th>
                <th>Data</th>
                <th>Azione</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $res = $conn->query("
            SELECT a.id AS art_id, a.titolo, a.likes, a.data_creazione, p.id AS pref_id
            FROM articoli a
            LEFT JOIN preferences p ON a.titolo = CONCAT(p.cantante, ' - ', p.canzone)
            ORDER BY a.data_creazione DESC
        ");

        if ($res && $res->num_rows > 0):
            while ($row = $res->fetch_assoc()): ?>
            <tr>
                <td style="color: var(--text-muted);">#<?= $row['art_id'] ?></td>
                <td><strong><?= htmlspecialchars($row['titolo']) ?></strong></td>
                <td> <?= $row['likes'] ?></td>
                <td style="color: var(--text-muted); font-size: 0.88em;"><?= date('d/m/Y', strtotime($row['data_creazione'])) ?></td>
                <td>
                    <a href="articolo.php?id=<?= $row['art_id'] ?>" style="color: var(--primary); text-decoration: none; font-size: 0.88em; margin-right: 10px;">👁 Vedi</a>
                    <?php if ($row['pref_id']): ?>
                    <a href="delete_music.php?id=<?= $row['pref_id'] ?>"
                       onclick="return confirm('Eliminare questo articolo definitivamente?')"
                       class="delete-link" style="font-size: 0.85em; padding: 4px 10px;">🗑 Elimina</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile;
        else: ?>
            <tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 30px;">Nessun articolo trovato.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="container">
    <h3 style="font-family: var(--font-display); font-size: 1.5em; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 20px;">
        Gestione <span style="color: var(--primary);">Utenti</span>
    </h3>

    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Ruolo</th>
                <th>Registrato</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $users = $conn->query("SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC");
        while ($u = $users->fetch_assoc()):
        ?>
        <tr>
            <td style="color: var(--text-muted);">#<?= $u['id'] ?></td>
            <td>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div class="user-avatar-sm"><?= strtoupper(substr($u['username'], 0, 1)) ?></div>
                    @<?= htmlspecialchars($u['username']) ?>
                </div>
            </td>
            <td style="color: var(--text-dim); font-size: 0.9em;"><?= htmlspecialchars($u['email']) ?></td>
            <td>
                <?php if ($u['role'] === 'admin'): ?>
                    <span class="badge" style="background: rgba(255,68,68,0.15); color: var(--primary); border: 1px solid rgba(255,68,68,0.2);">Admin</span>
                <?php else: ?>
                    <span class="badge" style="background: var(--bg-elevated); color: var(--text-dim); border: 1px solid var(--border);">User</span>
                <?php endif; ?>
            </td>
            <td style="color: var(--text-muted); font-size: 0.88em;"><?= date('d/m/Y', strtotime($u['created_at'])) ?></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include "footer.php"; ?>
