<?php
include "db.php";

if (isset($_SESSION['user_id']) && isset($_GET['id'])) {
    $id_to_delete = (int)$_GET['id'];
    $is_admin = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin');
    if ($is_admin) {
        $stmt = $conn->prepare("SELECT cantante, canzone, immagine FROM preferences WHERE id = ?");
        $stmt->bind_param("i", $id_to_delete);
    } else {
        $stmt = $conn->prepare("SELECT cantante, canzone, immagine FROM preferences WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $id_to_delete, $_SESSION['user_id']);
    }

    $stmt->execute();
    $info = $stmt->get_result()->fetch_assoc();

    if ($info) {
        $titolo = $info['cantante'] . " - " . $info['canzone'];
        if ($info['immagine'] && file_exists("uploads/" . $info['immagine'])) {
            unlink("uploads/" . $info['immagine']);
        }
        $del_art = $conn->prepare("DELETE FROM articoli WHERE titolo = ?");
        $del_art->bind_param("s", $titolo);
        $del_art->execute();
        $del_pref = $conn->prepare("DELETE FROM preferences WHERE id = ?");
        $del_pref->bind_param("i", $id_to_delete);
        $del_pref->execute();
    }
}

header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'index.php'));
exit;