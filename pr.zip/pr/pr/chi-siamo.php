<?php include "db.php"; include "header.php"; ?>

<div class="container" style="text-align: center; padding: 60px 40px;">
    <div style="font-size: 3em; margin-bottom: 16px;"></div>
    <h2 style="font-family: var(--font-display); font-size: 3.5em; letter-spacing: 4px; text-transform: uppercase; color: var(--text); line-height: 1; margin-bottom: 16px;">
        La nostra <span style="color: var(--primary);">Visione</span>
    </h2>
    <p style="font-size: 1.1em; color: var(--text-dim); max-width: 600px; margin: 0 auto; line-height: 1.8;">
        Beltify non è solo un sito, è un <strong style="color: var(--text);">palcoscenico digitale</strong> dove le tue emozioni musicali prendono vita.
        Siamo nati per dare voce a chi vive di musica ogni giorno.
    </p>
</div>

<div class="features" style="margin-bottom: 30px;">
    <div class="vision-card">
        <div class="vision-number">01</div>
        <h3 style="font-size: 1.1em; font-weight: 700; margin-bottom: 10px;">Esplora</h3>
        <p style="color: var(--text-dim); font-size: 0.92em; line-height: 1.6;">
            Scopri nuovi generi e artisti attraverso i gusti autentici della nostra community.
            Ogni recensione è una porta su un universo musicale nuovo.
        </p>
    </div>
    <div class="vision-card">
        <div class="vision-number">02</div>
        <h3 style="font-size: 1.1em; font-weight: 700; margin-bottom: 10px;">Condividi</h3>
        <p style="color: var(--text-dim); font-size: 0.92em; line-height: 1.6;">
            Non solo titoli: scrivi cosa significa per te quella canzone. Le emozioni sono il cuore di Beltify.
        </p>
    </div>
    <div class="vision-card">
        <div class="vision-number">03</div>
        <h3 style="font-size: 1.1em; font-weight: 700; margin-bottom: 10px;">Connettiti</h3>
        <p style="color: var(--text-dim); font-size: 0.92em; line-height: 1.6;">
            Commenta, metti like e scambia opinioni con persone che condividono la tua stessa passione.
        </p>
    </div>
</div>

<div class="container">
    <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 40px; align-items: center;">
        <div style="text-align: center;">
            <div style="font-family: var(--font-display); font-size: 5em; color: var(--primary); letter-spacing: 4px; line-height: 1; opacity: 0.8;">2026</div>
            <div style="font-size: 0.85em; color: var(--text-muted); margin-top: 8px; text-transform: uppercase; letter-spacing: 2px;">Anno di fondazione</div>
        </div>
        <div>
            <h3 style="font-family: var(--font-display); font-size: 1.8em; letter-spacing: 2px; text-transform: uppercase; color: var(--text); margin-bottom: 16px;">
                Come è nata <span style="color: var(--primary);">Beltify</span>
            </h3>
            <p style="color: var(--text-dim); line-height: 1.8; font-size: 0.95em;">
                Beltify nasce dall'idea semplice che la musica meriti più di un semplice "mi piace".
                Ogni brano racconta una storia, evoca un ricordo, cambia una giornata.
                Volevamo creare uno spazio dove queste storie potessero emergere.
            </p>
            <p style="color: var(--text-dim); line-height: 1.8; font-size: 0.95em; margin-top: 12px;">
                Siamo una piccola community italiana, ma con una visione grande: diventare il punto di riferimento
                per chi vuole parlare di musica in modo autentico, senza algoritmi che dettano i gusti.
            </p>
        </div>
    </div>
</div>

<div class="container">
    <h3 style="font-family: var(--font-display); font-size: 1.8em; letter-spacing: 2px; text-transform: uppercase; color: var(--text); margin-bottom: 24px; text-align: center;">
        I nostri <span style="color: var(--primary);">Valori</span>
    </h3>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
        <div class="info-section">
            <h3> Privacy prima di tutto</h3>
            <p>Non vendiamo i tuoi dati. Non usiamo advertising invasivo. La tua esperienza è nostra.</p>
        </div>
        <div class="info-section">
            <h3> Community autentica</h3>
            <p>Nessun bot, nessun contenuto sponsorizzato. Solo vere recensioni di veri appassionati.</p>
        </div>
        <div class="info-section">
            <h3> Zero filtri algoritmici</h3>
            <p>I contenuti sono mostrati in ordine cronologico. Ogni voce ha lo stesso peso.</p>
        </div>
        <div class="info-section">
            <h3> Dialogo rispettoso</h3>
            <p>Crediamo che si possa parlare di musica con passione e rispetto allo stesso tempo.</p>
        </div>
    </div>
</div>

<div class="container" style="text-align: center; padding: 50px 40px;">
    <h3 style="font-family: var(--font-display); font-size: 2.5em; letter-spacing: 3px; text-transform: uppercase; margin-bottom: 16px;">
        Unisciti alla <span style="color: var(--primary);">rivoluzione</span>
    </h3>
    <p style="color: var(--text-dim); margin-bottom: 28px; font-size: 1em;">
        Inizia a condividere la tua musica oggi. È gratis, sempre.
    </p>
    <div style="display: flex; gap: 14px; justify-content: center; flex-wrap: wrap;">
        <a href="register.php" class="cta">Registrati Gratis</a>
        <a href="articoli_list.php" class="cta secondary">Esplora le Recensioni</a>
    </div>
</div>

<?php include "footer.php"; ?>
