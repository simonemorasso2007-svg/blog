    </main>

    <footer class="footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h4>Navigazione</h4>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="articoli_list.php">Recensioni</a></li>
                    <li><a href="chi-siamo.php">Chi Siamo</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li><a href="home.php">Il Mio Profilo</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Legale</h4>
                <ul>
                    <li><a href="privacy.php">Privacy Policy</a></li>
                    <li><a href="privacy.php#cookie">Cookie Policy</a></li>
                    <li><a href="privacy.php#termini">Termini di Servizio</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Account</h4>
                <ul>
                    <?php if (!isset($_SESSION['user_id'])): ?>
                        <li><a href="login.php">Accedi</a></li>
                        <li><a href="register.php">Registrati</a></li>
                    <?php else: ?>
                        <li><a href="home.php">Aggiungi Brano</a></li>
                        <li><a href="articoli_list.php">Esplora</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Contatti</h4>
                <p> info@beltify.it<br>
                    privacy@beltify.it<br>
                    Genoa, Italy</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© <?= date("Y") ?> <span>Beltify</span> — Fatto con  per la musica</p>
        </div>
    </footer>
</body>
</html>
