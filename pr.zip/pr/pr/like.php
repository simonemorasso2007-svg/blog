<?php
include "db.php";
if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$art_id = (int)$_GET['id'];
$stmt = $conn->prepare("SELECT id FROM articolo_likes WHERE user_id = ? AND articolo_id = ?");
$stmt->bind_param("ii", $user_id, $art_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $conn->query("INSERT INTO articolo_likes (user_id, articolo_id) VALUES ($user_id, $art_id)");
    $conn->query("UPDATE articoli SET likes = likes + 1 WHERE id = $art_id");
} else {
    $conn->query("DELETE FROM articolo_likes WHERE user_id = $user_id AND articolo_id = $art_id");
    $conn->query("UPDATE articoli SET likes = likes - 1 WHERE id = $art_id");
}

header("Location: " . $_SERVER['HTTP_REFERER']);
exit;