<?php include "db.php"; ?>
<?php include "header.php"; ?>

<div class="container" style="padding: 0; overflow: hidden; border-radius: 16px;">
    <div class="hero" style="padding: 70px 40px 50px;">
        <div class="hero-eyebrow"> La community musicale italiana</div>
        <h2>Condividi la tua<br><span>passione</span></h2>
        <p>Salva i tuoi brani preferiti, leggi le recensioni della community e connettiti con chi ama la tua stessa musica.</p>
        <div class="hero-buttons">
            <?php if (!isset($_SESSION['user_id'])): ?>
                <a href="register.php" class="cta">Inizia Gratis</a>
                <a href="login.php" class="cta secondary">Accedi</a>
            <?php else: ?>
                <a href="home.php" class="cta">Il Mio Profilo</a>
                <a href="articoli_list.php" class="cta secondary">Esplora Recensioni</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
$total_users = $conn->query("SELECT COUNT(*) as n FROM users")->fetch_assoc()['n'];
$total_articles = $conn->query("SELECT COUNT(*) as n FROM articoli")->fetch_assoc()['n'];
$total_likes = $conn->query("SELECT COALESCE(SUM(likes),0) as n FROM articoli")->fetch_assoc()['n'];
?>

<div class="stats-bar">
    <div class="stat-item">
        <div class="stat-number"><?= $total_users ?>+</div>
        <div class="stat-label">Utenti</div>
    </div>
    <div class="stat-item">
        <div class="stat-number"><?= $total_articles ?>+</div>
        <div class="stat-label">Recensioni</div>
    </div>
    <div class="stat-item">
        <div class="stat-number"><?= $total_likes ?>+</div>
        <div class="stat-label">Like totali</div>
    </div>
</div>

<div class="features">
    <div class="feature">
        <span class="feature-icon"></span>
        <h3>Salva i Preferiti</h3>
        <p>Archivia artisti e canzoni del cuore con note personali, voto e foto.</p>
    </div>
    <div class="feature">
        <span class="feature-icon"></span>
        <h3>Condividi</h3>
        <p>Racconta cosa significa per te ogni brano e condividilo con la community.</p>
    </div>
    <div class="feature">
        <span class="feature-icon"></span>
        <h3>Scopri</h3>
        <p>Leggi le recensioni degli altri utenti e lasciati ispirare da nuove sonorità.</p>
    </div>
</div>

<?php
$latest = $conn->query("SELECT * FROM articoli ORDER BY data_creazione DESC LIMIT 3");
if ($latest->num_rows > 0):
?>
<div style="margin-top: 40px;">
    <div class="page-header" style="margin-bottom: 20px;">
        <h2 style="font-family: var(--font-display); font-size: 1.8em; letter-spacing: 2px; text-transform: uppercase; color: var(--text);">
            Ultime <span style="color: var(--primary);">Recensioni</span>
        </h2>
        <p style="color: var(--text-dim); margin-top: 6px; font-size: 0.9em;">Le più recenti dalla community</p>
    </div>
    <div class="articles-grid">
        <?php while ($art = $latest->fetch_assoc()): ?>
        <div class="music-card">
            <?php if ($art['immagine']): ?>
                <div class="card-img-wrapper">
                    <img src="uploads/<?= $art['immagine'] ?>" class="card-img" alt="<?= htmlspecialchars($art['titolo']) ?>">
                </div>
            <?php else: ?>
                <div class="img-placeholder"></div>
            <?php endif; ?>
            <div class="card-content">
                <h3><?= htmlspecialchars($art['titolo']) ?></h3>
                <p><?= nl2br(htmlspecialchars(mb_substr($art['descrizione'], 0, 90))) ?>...</p>
                <div class="card-footer">
                    <a href="articolo.php?id=<?= $art['id'] ?>" class="btn-more">Scopri →</a>
                    <span class="like-badge"> <?= $art['likes'] ?></span>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <div style="text-align:center; margin-top: 25px;">
        <a href="articoli_list.php" class="cta secondary">Vedi tutte le recensioni →</a>
    </div>
</div>
<?php endif; ?>

<?php include "footer.php"; ?>
