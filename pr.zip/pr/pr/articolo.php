<?php
include "db.php";
include "header.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $conn->prepare("
    SELECT a.*, p.id as pref_id, p.user_id as owner_id, p.genere, p.voto, p.cantante, p.canzone, u.username as autore
    FROM articoli a
    LEFT JOIN preferences p ON a.titolo = CONCAT(p.cantante, ' - ', p.canzone)
    LEFT JOIN users u ON p.user_id = u.id
    WHERE a.id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$art = $stmt->get_result()->fetch_assoc();

$is_admin = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin');
$is_owner = (isset($_SESSION['user_id']) && isset($art['owner_id']) && $_SESSION['user_id'] == $art['owner_id']);

$user_liked = false;
if (isset($_SESSION['user_id']) && $art) {
    $lk = $conn->prepare("SELECT id FROM articolo_likes WHERE user_id = ? AND articolo_id = ?");
    $lk->bind_param("ii", $_SESSION['user_id'], $id);
    $lk->execute();
    $user_liked = $lk->get_result()->num_rows > 0;
}
?>

<div class="container" style="max-width: 820px; margin: 0 auto;">
    <?php if ($art): ?>

        <div class="article-header">
            <div>
                <?php if ($art['genere']): ?>
                    <span class="badge badge-genre" style="margin-bottom: 10px; display: inline-block;">
                        <?= htmlspecialchars($art['genere']) ?>
                    </span>
                <?php endif; ?>
                <h2 class="article-title"><?= htmlspecialchars($art['titolo']) ?></h2>

                <div style="display: flex; align-items: center; gap: 16px; margin-top: 12px; flex-wrap: wrap;">
                    <?php if ($art['autore']): ?>
                        <span style="font-size: 0.9em; color: var(--text-dim);">
                             @<?= htmlspecialchars($art['autore']) ?>
                        </span>
                    <?php endif; ?>
                    <span style="font-size: 0.85em; color: var(--text-muted);">
                         <?= date('d M Y', strtotime($art['data_creazione'])) ?>
                    </span>
                    <?php if ($art['voto']): ?>
                        <span class="stars"><?= str_repeat('', $art['voto']) ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($is_admin || $is_owner): ?>
                <a href="delete_music.php?id=<?= $art['pref_id'] ?>"
                   onclick="return confirm('Vuoi eliminare definitivamente questo articolo?')"
                   class="delete-link"> Elimina</a>
            <?php endif; ?>
        </div>

        <?php if ($art['immagine']): ?>
            <div class="article-image-wrapper">
                <img src="uploads/<?= $art['immagine'] ?>" alt="<?= htmlspecialchars($art['titolo']) ?>">
            </div>
        <?php endif; ?>

        <div class="article-body">
            <?= nl2br(htmlspecialchars($art['descrizione'])) ?>
        </div>

        <div style="margin-top: 30px; display: flex; align-items: center; gap: 16px; padding: 20px 0; border-top: 1px solid var(--border);">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="like.php?id=<?= $id ?>" class="like-badge" style="font-size: 1em; padding: 10px 20px; <?= $user_liked ? 'border-color: var(--primary); background: var(--primary-glow);' : '' ?>">
                    <?= $user_liked ? '' : '' ?> <?= $art['likes'] ?> <?= $art['likes'] == 1 ? 'like' : 'like' ?>
                </a>
                <span style="font-size: 0.85em; color: var(--text-muted);"><?= $user_liked ? 'Hai messo like' : 'Clicca per mettere like' ?></span>
            <?php else: ?>
                <span class="like-badge" style="font-size: 1em; padding: 10px 20px;"> <?= $art['likes'] ?> like</span>
                <a href="login.php" style="font-size: 0.85em; color: var(--primary);">Accedi per mettere like</a>
            <?php endif; ?>
        </div>

    <?php else: ?>
        <div style="text-align: center; padding: 60px 0;">
            <div style="font-size: 4em; margin-bottom: 20px;"></div>
            <h2 style="color: var(--text-dim);">Articolo non trovato</h2>
            <a href="articoli_list.php" class="cta secondary" style="display: inline-block; margin-top: 20px;">← Torna alla lista</a>
        </div>
    <?php endif; ?>

    <div class="comments-section">
        <h3> Commenti</h3>

        <?php
        $stmt_comm = $conn->prepare("
            SELECT commenti.id, commenti.commento, commenti.user_id, users.username
            FROM commenti
            JOIN users ON users.id = commenti.user_id
            WHERE articolo_id = ?
            ORDER BY commenti.id DESC
        ");
        $stmt_comm->bind_param("i", $id);
        $stmt_comm->execute();
        $res = $stmt_comm->get_result();

        if ($res->num_rows === 0): ?>
            <p style="color: var(--text-muted); font-style: italic; padding: 20px 0;">Ancora nessun commento. Sii il primo!</p>
        <?php endif;

        while ($row = $res->fetch_assoc()): ?>
        <div class="comment-item">
            <div class="user-avatar"><?= strtoupper(substr($row['username'], 0, 1)) ?></div>
            <div class="comment-text">
                <strong>@<?= htmlspecialchars($row['username']) ?></strong>
                <p><?= htmlspecialchars($row['commento']) ?></p>
                <?php if ($is_admin || (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $row['user_id'])): ?>
                    <a href="delete_comment.php?id=<?= $row['id'] ?>"
                       onclick="return confirm('Eliminare questo commento?')"
                       class="comment-delete">🗑 Elimina</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>

        <?php if (isset($_SESSION['user_id'])): ?>
        <div class="comment-form">
            <form method="POST" action="save-comment.php">
                <textarea name="commento" required placeholder="Scrivi un commento... (max 50 caratteri)" maxlength="50"></textarea>
                <input type="hidden" name="articolo_id" value="<?= $id ?>">
                <button type="submit" style="width: auto; padding: 11px 24px;">Invia Commento</button>
            </form>
        </div>
        <?php else: ?>
            <p style="margin-top: 20px; color: var(--text-dim); font-size: 0.92em;">
                <a href="login.php" style="color: var(--primary); font-weight: 600;">Accedi</a> per lasciare un commento.
            </p>
        <?php endif; ?>
    </div>
</div>

<?php include "footer.php"; ?>
