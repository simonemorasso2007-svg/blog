<?php
include "db.php";

if (isset($_SESSION['user_id']) && isset($_GET['id'])) {
    $comment_id = (int)$_GET['id'];
    $user_id = $_SESSION['user_id'];
    $is_admin = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin');

    if ($is_admin) {
        $stmt = $conn->prepare("DELETE FROM commenti WHERE id = ?");
        $stmt->bind_param("i", $comment_id);
    } else {
        $stmt = $conn->prepare("DELETE FROM commenti WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $comment_id, $user_id);
    }

    $stmt->execute();
}
header("Location: " . $_SERVER['HTTP_REFERER']);
exit;